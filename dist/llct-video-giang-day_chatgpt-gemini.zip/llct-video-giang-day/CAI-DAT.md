# Trợ lý soạn video giảng dạy LLCT — cho ChatGPT và Gemini (web, điện thoại)

Gói này biến ChatGPT hoặc Gemini thành trợ lý **soạn** video giảng dạy Lý luận chính trị: hỏi thông tin bài → lời thoại đúng
giáo trình → tự kiểm → bảng phân cảnh vẽ tay → xuất `loi-thoai.txt`, bản đọc cho giọng máy, `phan-canh.json`.
Mặc định: vẽ tay, ngang 16:9, giọng kiểu giảng đường (nam trung niên, truyền cảm, dõng dạc); bản dọc TikTok/Shorts khi bạn yêu cầu.

**Giới hạn:** ChatGPT và Gemini trên web không chạy được Chrome, ffmpeg, whisper nên **không dựng ra file video mp4**.
Dựng video: dùng gói `dashi-animationstyle` trên máy tính (Claude Code, Codex CLI hoặc Gemini CLI), đưa các file trợ lý vừa soạn vào.

## ChatGPT — tạo GPT riêng (cần gói trả phí có mục «GPTs»)

1. chatgpt.com → **Khám phá GPT** → **Tạo** → thẻ **Cấu hình**.
2. **Tên**: «Soạn video giảng dạy LLCT». **Hướng dẫn**: dán toàn bộ nội dung `HUONG-DAN-TRO-LY.md`.
3. **Kiến thức**: tải lên 6 file trong thư mục `tri-thuc/`.
4. Lưu (chế độ «Chỉ tôi» hoặc «Bất kỳ ai có liên kết» để chia sẻ đồng nghiệp).

Không có GPTs: tạo một **Dự án (Project)**, dán `HUONG-DAN-TRO-LY.md` vào «Hướng dẫn», thêm 6 file vào «Tệp».

## Gemini — tạo Gem

1. gemini.google.com → **Khám phá Gem** → **Gem mới**.
2. **Tên**: «Soạn video giảng dạy LLCT». **Hướng dẫn**: dán toàn bộ nội dung `HUONG-DAN-TRO-LY.md`.
3. **Kiến thức**: tải lên 6 file trong `tri-thuc/`. Lưu; chia sẻ Gem qua nút **Chia sẻ**.

## Dùng thử

> Soạn video 1 phút về «quy luật lượng – chất» cho sinh viên năm nhất, tôi sẽ tự ghi âm.

Trợ lý hỏi thêm một lần, đưa lời thoại và bảng phân cảnh để bạn duyệt, rồi xuất các file. Mọi trích dẫn, số liệu: giảng viên kiểm lại trước khi dùng.
