# dashi-animationstyle cho Codex CLI và Gemini CLI

Bản đầy đủ: dựng được file video mp4 trên máy (cần Node 22+, ffmpeg, Google Chrome; macOS hoặc Linux; Windows dùng WSL).
Dùng với tác tử chạy lệnh trên máy: **OpenAI Codex CLI** hoặc **Google Gemini CLI** (cũng dùng được với Claude Code).

## Cài

1. Giải nén vào thư mục bạn sẽ làm video, ví dụ `~/Video-giang-day/`:

   ```bash
   mkdir -p ~/Video-giang-day && cd ~/Video-giang-day
   unzip ~/Downloads/dashi-animationstyle_codex-gemini-cli.zip
   cp -r dashi-animationstyle-cli/. . && rm -rf dashi-animationstyle-cli
   bash dashi-animationstyle/install.sh            # font, whisper (~550 MB), tự kiểm tra
   bash dashi-animationstyle/install.sh --voice    # tùy chọn: giọng máy / nhân bản giọng
   ```

   Thư mục giờ có `AGENTS.md` (Codex đọc), `GEMINI.md` (Gemini CLI đọc) và `dashi-animationstyle/`.

2. Mở tác tử **trong thư mục đó**: `codex` hoặc `gemini`.

   Bản Codex / Gemini CLI mới có hỗ trợ Agent Skills: có thể chép thêm `dashi-animationstyle/` vào thư mục skills của công cụ
   (ví dụ `~/.codex/skills/`); không bắt buộc — `AGENTS.md` / `GEMINI.md` đã đủ.

## Dùng

> Làm video giảng dạy 1 phút về «quy luật lượng – chất», giọng của tôi trong file `ghi-am.m4a`.

Mặc định vẽ tay, ngang 16:9, giọng kiểu giảng đường; bản dọc TikTok/Shorts khi bạn yêu cầu. Xem thử ví dụ:
«tạo dự án từ ví dụ llct-gia-tri-thang-du rồi render».

Lưu ý: tác tử cần quyền chạy lệnh và ghi file (Codex: chế độ `--full-auto` hoặc duyệt từng lệnh; Gemini CLI: duyệt lệnh khi hỏi).
Render một đoạn 1 phút mất vài phút; nên để tác tử chạy render ở chế độ nền và báo khi xong.
