# Dựng video hoạt hình / video giảng dạy LLCT

Thư mục `dashi-animationstyle/` là một Agent Skill (định dạng SKILL.md). Khi người dùng muốn làm video hoạt hình từ lời thoại
tiếng Việt hoặc tiếng Anh, hoặc video giảng dạy Lý luận chính trị (Triết học, KTCT, CNXHKH, Lịch sử Đảng, TTHCM):

1. Đọc `dashi-animationstyle/SKILL.md` và làm theo. Trong đó `$SKILL` = đường dẫn tuyệt đối tới thư mục `dashi-animationstyle/`.
2. Video giảng dạy LLCT: đọc thêm `dashi-animationstyle/knowledge/llct-giang-day.md`.
   Mặc định: phong cách vẽ tay (`ve-tay`), khung ngang 16:9, giọng kiểu `giang-duong` (nam trung niên, truyền cảm, dõng dạc);
   bản dọc 9:16 và phong cách khác chỉ làm khi người dùng yêu cầu.
3. SKILL.md viết cho Claude Code; các bước đều là lệnh shell (`node …`, `python3 …`, `ffmpeg`), chạy được trong mọi tác tử có
   quyền chạy lệnh. Chỗ nào nhắc «Claude» thì hiểu là bạn. Phần ghi chú tiếng Trung trong SKILL.md và các thẻ phong cách là
   hướng dẫn gốc — đọc hiểu bình thường; trả lời người dùng bằng tiếng Việt (hoặc tiếng Anh nếu họ dùng tiếng Anh).
4. Luôn dừng 2 lần chờ người dùng duyệt: (1) lời thoại + bảng phân cảnh, (2) ảnh tĩnh — rồi mới render.
5. Lần đầu trên máy: `bash dashi-animationstyle/install.sh` (font, whisper); tạo giọng máy / nhân bản giọng: thêm `--voice`.

Không ghi tác phẩm vào trong `dashi-animationstyle/`; đặt ở `./video-hoat-hinh/<tên>/`.
